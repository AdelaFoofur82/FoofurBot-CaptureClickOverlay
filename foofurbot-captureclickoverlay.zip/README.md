﻿# FoofurBot-CaptureClickOverlay

THIS EXTENSION IS FOR ADVANCED USERS. IF YOU AREN'T A DEVELOPER THIS EXTENSION WON'T BE HELPFUL FOR YOU. IF YOU HAVE BEEN ASKED BY THIRD PARTIES TO INSTALL THIS EXTENSION, PLEASE BE SURE YOU ARE CONFIDENT WITH THEM.

This extension allows to capture interaction from your viewers on the screen of your stream and send the mouse events to a WebSocket server of your own, in order to allow to develop games, polls and other creative stuff! 

This extension captures click, mousedown, mouseup and mousemove events. If the user grants permission, you will get information of the user triggering the events. It also provides information about latency and the context of the viewer. All the information is sent to a WebSocket server you provide on settings.

If you need more help, check the extension configuration.